Drop real photos here (e.g. photo-1.jpg, photo-2.jpg ...).

To wire a photo into a frame, open index.html, find the "GALLERY" section,
and inside any .gallery-frame div replace the emoji <span class="icon"> with
a real image, for example:

  <div class="gallery-frame" data-icon="images/gallery/photo-1.jpg"
       data-caption="our first photo together">
    <img src="images/gallery/photo-1.jpg" alt="our first photo together"
         loading="lazy" style="width:100%;height:100%;object-fit:cover;border-radius:16px;">
  </div>

The lightbox script already reads data-icon / data-caption, so once an <img>
is in place the tap-to-enlarge behaviour keeps working without further JS
changes. Use loading="lazy" on every gallery <img> to keep the page fast.
