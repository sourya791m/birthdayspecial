# Fonts

This project loads its three typefaces — **Playfair Display**, **Cormorant
Garamond**, and **Quicksand** — from the Google Fonts CDN (see the `<link>`
tags in `index.html`). That keeps the initial download small and the fonts
always up to date, which is why this folder is empty by default.

## Self-hosting (optional)

If you'd rather not depend on Google Fonts (for offline use, stricter
privacy, or a faster first paint on a slow connection), you can self-host:

1. Download the `.woff2` files for Playfair Display, Cormorant Garamond, and
   Quicksand from [Google Fonts](https://fonts.google.com/).
2. Place them in this `fonts/` folder.
3. In `style.css`, add `@font-face` rules pointing at `fonts/your-file.woff2`
   for each weight/style you use.
4. Remove the two `<link rel="preconnect">` tags and the Google Fonts
   `<link rel="stylesheet">` tag from `index.html`.
