Drop your romantic instrumental birthday track here, named exactly:

    romantic-birthday-instrumental.mp3

index.html already points to music/romantic-birthday-instrumental.mp3, so once
the file is in this folder, the music toggle button in the top-right corner
will start working immediately — no code changes needed.

Notes:
- Browsers block autoplay-with-sound until the visitor interacts with the
  page at least once, so the button may start muted; that's expected
  behaviour, not a bug.
- Keep the file reasonably small (a compressed MP3 under ~3–5MB) so the page
  still loads fast.
